#include<iostream>
#include <cstdlib>
using namespace std;
template<class T>
class box{
      public:
      T value;
      box* next;
      box(){

        next = 0;
      }
      box(T a){
              value=a;
              next=0;
    }


      };
template<class T>
class linked_list{
    public:
        int size = 0;
        box<T> *head;
        box<T> *tail;

        linked_list(){
            head=0;
            tail=0;
        }
        linked_list(const linked_list<T> & list){
            head = new box<T>;
            head = list.head;
            tail = new box<T>;
            tail = list.tail;
            size = list.size;
        }
    void insert(T v){// insert in the end

        box<T> *temp= new box<T>(v);
        if(head==0){
            head=temp;
            tail=temp;
        }
        else{
            tail->next=temp;
            tail=temp;
        }
        size++;
    }
    void back_insert(T v){// insert element in the beginning
        box<T> *temp=new box<T>(v);
        if(head==0){
            head=temp;
            tail=temp;
        }
        else{
            temp->next=head;
            head=temp;
        }
        size++;
    }
    void print(){//print all not used
        box<T> *temp=head;
        while(temp!=NULL){
            cout<<temp->value<<endl;
            temp=temp->next;
        }

    }
    void delete_head(){//remove first ekement
        box<T> *temp;

        temp=head;
        head=head->next;
        delete temp;
        size--;
    }
    void delete_mid(int x){//remove any the xth element
        int cont=0;
        box<T> *temp,*temp2;
        temp=head;
        temp2 = temp->next;
        while(cont!=x-1){
            temp=temp->next;
            temp2=temp->next;
            cont++;
        }
        temp->next=temp2->next;
        temp2->next=0;
        delete temp2;
        size--;

}
    void delete_tail(){//remove the last element
         box<T> *temp=head, *temp2;
        while(temp->next!=tail){
            temp=temp->next;
            temp2 = temp->next;
        }

        temp2->next=0;

        delete temp2;
        tail = temp;
        size--;
    }
    void remove1(int index){// user the 3 delete methods to rmove any indexth element
        if(index == 0){
            delete_head();
        }else if(index == this->size-1){
            delete_tail();
        }else{
            delete_mid(index);
        }
    }
    int find(T value){// return index of value or -1 if it's not found
        if(tail->value == value){
            return size-1;
        }
        box<T> *temp;
        temp = head;
        int index = 0;
        while(temp->value != value && temp != tail){
            temp = temp->next;
            index++;
        }
        if(temp == tail && value != tail->value){
            index = -1;
        }
        return index;
    }
    T get(int index){//return element by index
        if(index == 0){
            return head->value;
        }else if(index == size-1){
            return tail->value;
        }
        int cont = 0;
        box<T> *temp;
        temp=head;
        while(cont != index){
            temp=temp->next;
            cont++;
            if(cont == index){
                return temp->value;
            }
        }
    }

};
