/*************************************
Program: main.cpp
Course: OOPDS
Year: 20015/16 Trimester 2
Name: Md Shakif Abdullah
ID: 1141327731
Lecture: TC03
Lab: TT07
Email: shakif.fahim@yahoo.com
Phone: 017-2026137
*************************************/
#include<iostream>
#include"LinkedList.cpp"
#include <fstream>
using namespace std;
//super class
linked_list<string> readDirectFlight(){
    ifstream reader;
     reader.open("direct flight.txt");
     string city = "";
     linked_list<string>list;
     for(int i = 0; !reader.eof(); i++){
        getline(reader, city);
        list.insert(city);
     }
     return list;
}
linked_list<string> readCity(){

     string city = "";
     linked_list<string>list;
     cout<<"choose your city\n";
     ifstream reader;
     reader.open("city-names.txt");
     for(int i = 0; !reader.eof(); i++){
        getline(reader, city);
        list.insert(city);
        cout<<i<<"."<<city<<endl;
     }
     return list;
}
void addToFile(char* fileName, string value){//get name of file and value to add to
    ofstream writer;
    writer.open(fileName, ios::app);
    writer<<"\n"<<value;
}
void removeFromFile(char* fileName){//get name of file and value to remove from
    string value = "";
    cout<<"choose from cities\n\n";
    linked_list <string>v;
    string city = "";
    ifstream reader;
    ofstream writer;
    reader.open(fileName);
    while(!reader.eof()){
        getline(reader, city);
        cout<<"\n"<<city;
        v.insert(city);
    }
    cout<<endl<<endl<<"Enter what to remove: ";
    cin.ignore();
    getline(cin, value);
    reader.close();
    int index = v.find(value);
    v.remove1(index);
    writer.open(fileName);
    writer.close();
    writer.open(fileName, ios::app);
    //cout<<"size = "<<v.size<<endl;
    for(int i = 0; i< v.size;i++){
        string val = "";
        if(i<v.size-1){
            val = v.get(i)+"\n";
        }else{
            val = v.get(i);
        }
        //cout<<"Heloo true     "<<val<<endl;
        writer<<val;
    }
    writer.close();
}
class Attraction{
protected: // optional declaration
    int id;
    string name;
    int typeId;
public:
    Attraction (int i, string n, int tid){
            id=i;
            name=n;
            typeId=tid;
    }
string detType(){
    if(typeId==1){return "Sport";}
    if(typeId==2){return "culture";}
    if(typeId==3){return "Shopping";}
}
virtual string getName()=0;
virtual int getTypeId()=0;
virtual int getid()=0;
virtual void display()=0;
virtual int getAgeLimit()=0;
virtual  double getEntranceFee()=0;
virtual  string getMalls()=0;
};
//city class
class City {
    int id;//private
    string name;
    linked_list<Attraction*> attraction; //vector array for the attraction class as pointer.
    public:
            City(){

            }
           City(linked_list<Attraction*>va){
                attraction=va;
            }
    linked_list<Attraction*> getattraction(){
                return attraction;
    }
             void setname(string n){name=n;}
            string getname(){return name;}
};
//sports subclass Inherited from attraction class
class Sports:public Attraction{
int ageLimit; // according to the class UML diagram
public:
    Sports (int i, string n, int tid, int age):Attraction(i, n, tid), ageLimit(age){
        this->ageLimit = age;
    }
    string getName() {return name;}
    int getTypeId() {return typeId;}
    int getid(){return id;}
    double getEntranceFee(){
        return 0.0;
    }
    string getMalls(){
        return 0;
    }
    int getAgeLimit(){return ageLimit;}
    void display () {
        cout<<"Sport name is=" << getName() <<  "\nAge limit=" << ageLimit<< endl;
    }
};

//Culture subclass Inherited from attraction class
class Culture:public Attraction{
double entranceFee;
public:
    Culture(int i, string n, int tid, int e):Attraction(i, n, tid), entranceFee(e){
        this->entranceFee = e;
    }
    string getName() {return name;}
    int getTypeId() {return typeId;}
    int getid(){return id;}
    double getEntranceFee(){return entranceFee;}
    int getAgeLimit(){
        return 0;
    }
    string getMalls(){
        return 0;
    }
    void display () {
        cout<<"Culture name is=" << getName() <<  "\nEntranceFee is(RM)=" << entranceFee<< endl;
                    }
};

//Shopping subclass Inherited from attraction class
class Shopping:public Attraction{
string malls;
public:
    Shopping(int i, string n, int tid, string m):Attraction(i, n, tid), malls(m){
        this->malls = m;
    }
    string getName() {return name;}
    int getTypeId() {return typeId;}
    int getid(){return id;}
    int getAgeLimit(){return 0;};
    double getEntranceFee(){
        return 0.0;
    }
    string getMalls(){return malls;}
    void display (){
        cout<<"Mall name is=" << getName() <<  "\nAddress=" << malls<< endl;
                   }
};

//main function
int main(){
    //#include <stdlib.h>
    //system("cls");
    //declare attraction vector object
     linked_list <Attraction*> att,att2;
     int option = 0;
     cout<< "choose option from blow:\n0.Admin\n1.User\n";
     cin>>option;
     if(option == 0){
        //here is admin part
        string ID = "", password = "", actualID = "", actualPassword = "";
        ifstream login;
        login.open ("login data.txt");
        getline (login,actualID);//read ID from login data.txt
        getline (login,actualPassword);////read password from login data.txt
        login.close();
        while(ID != actualID && password != actualPassword){// looping till user enter the right data
            cout<<"ID: ";
            cin>>ID;
            cout<<"\nPassword: ";
            cin>>password;
        }
        cout<<"\nHello "<<ID<<endl;
        cout<< "choose option from blow:\n0.city\n1.emergency-flights\n2.direct flight\n";
        cin>>option;//let admin choose what part he want to modify
        if(option == 0){//city part
            string city = "";
            cout<<"choose option from blow:\n0.add\n1.remove\n";
            cin>>option;
            if(option == 0){
                //add city
                cout<< "Enter city that you want to add: ";
                cin>>city;
                addToFile("city-names.txt", city);//this method add to any file. implemented above
            }else if(option == 1){
                //remove city
                removeFromFile("city-names.txt");// this method remove from any file. implemented above also
            }else{
                cout<< "error in choosing";
            }
        }else if(option == 1){//emergency part
            cout<<"choose option from blow:\n0.add\n1.remove\n";
            cin>>option;
            string flight;
            if(option == 0){
                //add emergency-flights
                cout<< "Enter emergency-flights that you want to add: ";

                cin.ignore();
                getline(cin, flight);
                addToFile("emergency-flights.txt", flight);
            }else if(option == 1){
                //remove emergency-flights
                removeFromFile("emergency-flights.txt");
            }else{
                cout<< "error in choosing";
            }
        }else if(option == 2){//direct flight part
            cout<<"choose option from blow:\n0.add\n1.remove\n";
            cin>>option;
            string flight;
            if(option == 0){
                //add direct flight
                cout<< "Enter direct flights that you want to add: ";

                cin.ignore();
                getline(cin, flight);
                addToFile("direct flight.txt", flight);
            }else if(option == 1){
                //remove direct flight
                removeFromFile("direct flight.txt");
            }else{
                cout<< "error in choosing";
            }
        }else{
            cout<< "error in choosing";
        }
     }else if(option == 1){//user part
        cout<< "Hello User\n";
        cout<<"choose atrraction or detail flight\n0.attraction\n1.detail flight\n";
        cin>>option;
        if(option == 0){//attraction part

        linked_list <Attraction*> attC2;
        linked_list <Attraction*> attC3;
        linked_list <Attraction*> attC4;
        linked_list <City>city;

//insert value to the sports,culture, shopping class with the attraction object
//city 1
        att.insert(new Sports(0,"Cyberjaya Go Cart Racing" , 1, 15));
        att.insert(new Sports(1,"Prima Avene Sports Center", 1, 13));
        att.insert(new Sports(2,"Cyberjaya Paintball Park", 1, 18));
        att.insert(new Culture(3,"Vally Music and Theater Fest" , 2, 180));
        att.insert(new Culture(4,"Film, Art Fest" , 2, 120));
        att.insert(new Culture(5,"Oriental Cultural Fest" , 2, 130));
        att.insert(new Shopping(6,"Dpulze" , 3, "Cyberjaya"));
        att.insert(new Shopping(7,"Shaftsbury" , 3, "Jalan Cyberjaya"));
        att.insert(new Shopping(8,"Cyberia Market" , 3, "Jalan Cyberia"));

        //city 2
        attC2.insert(new Sports(0,"Legoland" , 1, 12));
        attC2.insert(new Sports(1,"Jhor zoo", 1, 8));
        attC2.insert(new Sports(2,"Jahor Water Park", 1, 15));
        attC2.insert(new Culture(3,"Danga Bay" , 2, 280));
        attC2.insert(new Culture(4,"Intana Besar" , 2, 140));
        attC2.insert(new Culture(5,"Mount Pulai" , 2, 160));
        attC2.insert(new Shopping(6,"Rajakaliamman Shop" , 3, "Jalan Unkun punan"));
        attC2.insert(new Shopping(7,"Isfana Shop" , 3, "Jalan Trus Jahor"));
        attC2.insert(new Shopping(8,"Jahor Market" , 3, "Jalan Belukar"));

        //city 3
        attC3.insert(new Sports(0,"Sunway Lagoon Theme Parl" , 1, 15));
        attC3.insert(new Sports(1,"Aquaria KLCC", 1, 10));
        attC3.insert(new Sports(2,"Pool World", 1, 13));
        attC3.insert(new Culture(3,"KL Bird Park" , 2, 180));
        attC3.insert(new Culture(4,"Sultan Abdul building" , 2, 0));
        attC3.insert(new Culture(5,"Batu Cave" , 2, 0));
        attC3.insert(new Shopping(6,"Petronas Towar" , 3, "KLCC"));
        attC3.insert(new Shopping(7,"Menara Tower" , 3, "KLCC"));
        attC3.insert(new Shopping(8,"China Town" , 3, "Jalan Petaling, Kuala Lumpur"));

        //city 4
        attC4.insert(new Sports(0,"Water Park Complex" , 1, 12));
        attC4.insert(new Sports(1,"Taman Pan Carona", 1, 20));
        attC4.insert(new Sports(2,"Challenge Park", 1, 16));
        attC4.insert(new Culture(3,"Cultural Fest" , 2, 180));
        attC4.insert(new Culture(4,"International Convention Center" , 2, 120));
        attC4.insert(new Culture(5,"Putra Mosque" , 2, 0));
        attC4.insert(new Shopping(6,"Alamanda" , 3, "Wilayah, Putrajaya"));
        attC4.insert(new Shopping(7,"IoI City Mall" , 3, "Wilayah, Putrajaya"));
        attC4.insert(new Shopping(8,"Gaint Shopping Mall" , 3, "Puchong, Putrajaya"));


        //city name

        City c1(att);
        c1.setname("Cyberjaya");
        City c2(attC2);
        c2.setname("Jahor Bahru");
        City c3(attC3);
        c3.setname("Kuala Lumpur");
        City c4(attC4);
        c4.setname("Putrajaya");

        city.insert(c1);
        city.insert(c2);
        city.insert(c3);
        city.insert(c4);
        cout<<"Choose any city-->"<<endl;

        //print city name
        for(int i=0;i<city.size;i++){
        cout<<i<<" - "<<city.get(i).getname()<<endl;
                }
        cout<<"-->";
        int choooseCity;
        cin>>choooseCity;

        cout<<"1- Choose all attraction of the particular city"<<endl;
        cout<<"2- Choose attractions by various type"<<endl;
        cout<<"-->";

        int mode ;
        cin>>mode;

        //all attraction
        if(mode==1){
        cout<<"the attractions list in the city are--> "<<endl;
        att2=city.get(choooseCity).getattraction();
        for(int i=0;i<att2.size;i++){

        cout<<i<<" - "<<att2.get(i)->getName()<<endl;

                }
        cout<<"Choose a attraction from the above-->";
        int chooseattraction;
        cin>> chooseattraction;
        //detail
        cout<<"the attration you choose is--> "<<att2.get(chooseattraction)->getName()<<endl;

        string s=  att2.get(chooseattraction)-> detType();

        if(s=="Sport"){
            cout<<"The age limit= "<<att2.get(chooseattraction)->getAgeLimit();
        }
        else if(s=="culture"){
            cout<<"The EntranceFee= "<<att2.get(chooseattraction)->getEntranceFee();
        }
        else{
            cout<<"The address= "<<att2.get(chooseattraction)->getMalls();
        }
}

else if(mode==2){
//type of attraction
cout<< "Choose your attraction type->"<<endl;
att2=city.get(choooseCity).getattraction();
cout<<"1 - sports"<<endl;
cout<<"2 - culture"<<endl;
cout<<"3 - Shopping"<<endl;
cout<<"-->";
int type=0;
cin>>type;
int num=0;
linked_list<Attraction*>Vchoosen;
cout<<"choose your attraction for details-->"<<endl;
for(int i=0;i<att2.size;i++){
    if(att2.get(i)->getTypeId()==type){
        cout<<num<<" - "<<att2.get(i)->getName()<<endl;
        num++;
        Vchoosen.insert(att2.get(i));
    }
}
int youratt=0;
cout<<"-->";
cin>> youratt;
string ty;
if(type==1){
       ty="sport";
         }
if(type==2){
       ty="culture";
         }
if(type==3){
       ty="Shopping";
         }

        cout<<"the attration you choose is --> "<<Vchoosen.get(youratt)->getName()<<endl;

                   string s=  Vchoosen.get(youratt)-> detType();
                   if(s=="Sport"){
                  cout<<"Age limit= "<<Vchoosen.get(youratt)->getAgeLimit();
                  }
                  else if(s=="culture"){
                  cout<<"the EntranceFee= "<<Vchoosen.get(youratt)->getEntranceFee();
                  }
                  else{
                  cout<<"The address->"<<Vchoosen.get(youratt)->getMalls();
                  }
        }

     }else if(option == 1){
         //detail flight part
         string city = "", destination;
         linked_list <string> list = readCity();//read and print city from cit-names.txt file
         cout<<"your city is number: ";
         cin>>option;//choose his location
         cout<<endl;
         city = list.get(option);//get city that user select from list
         linked_list <string> list1 = readCity();
         cout<<"your destination is number: ";
         cin>>option;//choose his destination
         destination = list1.get(option);
         linked_list<string>flights = readDirectFlight();//read direct flight file
         //sort out the valur from the .txt file
         if(flights.find(city+" - "+destination) != -1){// sort out the value is right or wrong. if wrong then indirect. if true then direct.
            cout<<endl<<"your route is "<<city<<" to "<<destination<<" is direct flight"<<endl;
         }else{
            cout<<endl<<"your route is "<<city<<" to "<<destination<<" is indirect flight"<<endl;
         }

        }else{
            cout<<"error in choosing\n";
        }
    }
return 0;
}
